//
//  SearchViewController.h
//  iWords
//
//  Created by 张丁豪 on 2017/4/26.
//  Copyright © 2017年 zhangdinghao. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchViewController : BaseViewController

@end
