//
//  Net.h
//  App
//
//  Created by 张丁豪 on 16/9/7.
//  Copyright © 2016年 张丁豪. All rights reserved.
//


#ifndef Net_h
#define Net_h

// 有道
#define YouDaoSearchAPI @"http://fanyi.youdao.com/openapi.do?keyfrom=iWords1&key=1295348849&type=data&doctype=json&version=1.1&q="

#define YouDaoKey @"1295348849"
#define YouDaokeyfrom @"iWords1"


#define BaiDuAPI @"https://fanyi-api.baidu.com/api/trans/vip/translate"

#define BaiDuAppID @"20170426000045676"
#define BaiDuKey @"wmXttoeytPdXNYvBlUEG"



#endif /* Net_h */



