//
//  UIColor+FlatColors.h
//  项目框架
//
//  Created by 张东良 on 15/12/11.
//  Copyright (c) 2015年 张丁豪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (FlatColors)

+ (UIColor *)flatTurquoiseColor;

+ (UIColor *)flatGreenSeaColor;

+ (UIColor *)flatEmeraldColor;

+ (UIColor *)flatNephritisColor;

+ (UIColor *)flatPeterRiverColor;

+ (UIColor *)flatBelizeHoleColor;

+ (UIColor *)flatAmethystColor;

+ (UIColor *)flatWisteriaColor;

+ (UIColor *)flatWetAsphaltColor;

+ (UIColor *)flatMidnightBlueColor;

+ (UIColor *)flatSunFlowerColor;

+ (UIColor *)flatOrangeColor;

+ (UIColor *)flatCarrotColor;

+ (UIColor *)flatPumpkinColor;

+ (UIColor *)flatAlizarinColor;

+ (UIColor *)flatPomegranateColor;

+ (UIColor *)flatCloudsColor;

+ (UIColor *)flatSilverColor;

+ (UIColor *)flatConcreteColor;

+ (UIColor *)flatAsbestosColor;

+ (UIColor *)colorWithHex:(long)hexColor;

@end
