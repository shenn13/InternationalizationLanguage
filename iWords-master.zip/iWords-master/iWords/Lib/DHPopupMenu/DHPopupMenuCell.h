//
//  DHPopupMenuCell.h
//  DHPopupMenu
//
//  Created by 张丁豪 on 2017/4/18.
//  Copyright © 2017年 zhangdinghao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DHPopupMenuCell : UITableViewCell

@property (nonatomic, assign) BOOL isShowSeparator;
@property (nonatomic, strong) UIColor * separatorColor;

@end
